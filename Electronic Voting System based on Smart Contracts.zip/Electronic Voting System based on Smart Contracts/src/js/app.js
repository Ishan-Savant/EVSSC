App = {
  web3Provider: null,
  contracts: {},
  account: '0x0',
  hasVoted: false,
  winner: String,
  votesTally: {},

  init: function () {
    return App.initWeb3();
  },

  initWeb3: function () {
    if (typeof web3 !== 'undefined') {
      // If a web3 instance is already provided by Meta Mask.
      const ethEnabled = () => {
        if (window.ethereum) {
          // Creating new instance.
          window.web3 = new Web3(window.ethereum);
          window.ethereum.enable();
          return true;
        }
        return false;
      }
      // Prompt to install Ethereum compatible extension.
      if (!ethEnabled()) {
        alert("Please install an Ethereum-compatible browser or extension like MetaMask to use this dApp!");
      }
      web3 = window.web3;

      // Setting object to the instance.
      App.web3Provider = web3.currentProvider;
    } else {
      // Specify default instance if no web3 instance provided
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
      web3 = new Web3(App.web3Provider);
    }

    // Return result.
    return App.initContract();
  },

  initContract: function () {
    // Fetching the ABI's.
    $.getJSON("Election.json", function (election) {
      // Instantiate a new truffle contract from the artifact
      App.contracts.Election = TruffleContract(election);
      // Connect provider to interact with contract
      App.contracts.Election.setProvider(App.web3Provider);

      // Listens to event emitted.
      App.listenForEvents();

      // // Renders the UI.
      return App.render();
    });
  },

  // Listen for events emitted from the contract
  listenForEvents: function () {
    App.contracts.Election.deployed().then(function (instance) {
      // Restart Chrome if you are unable to receive this event
      // This is a known issue with Metamask
      // MetaMask/metamask-extension#2393
      instance.votedEvent({}, {
        fromBlock: 'latest',
        toBlock: 'latest'
      }).watch(function (error, event) {
        console.log("event triggered", event)
        // Reload when a new vote is recorded
        App.loadContract();
      });
    });
  },



  render: function () {

    // Hide show Elements.
    $("#registration").show();
    $("#maincontent").hide()
    $("#declareresults").hide();

    // Load account data
    web3.eth.getCoinbase(function (err, account) {
      if (err === null) {
        // Setting the user's account.
        App.account = account;
        console.log("Account ID : ", account)
      }
    });
  },

  loadContract: function () {

    $("#declareresults").hide();

    let electionInstance;
    App.contracts.Election.deployed().then(function (instance) {
      electionInstance = instance;
      return instance.candidateCount();
    }).then(function (candidateCount) {

      // Empty template to populate front-end.
      let candidatesResults = $("#candidatesResults");
      candidatesResults.empty();

      // Empty template to populate front-end.
      let candidatesSelect = $('#candidatesSelect');
      candidatesSelect.empty();

      // Fetching images/avatar
      let candidateImages = {
        1: "cb.png",
        2: "mg.png",
        3: "jt.png",
        4: "pb.png",
        5: "rs.png",
        6: "rg.png"
      };
      
      // Creating empty object to store key, value pair of candidate and their votes.
      let votesObj = {};

      // Iterating, adding and rendering each candidate to the candidate list.
      for (let i = 1; i <= candidateCount; i++) {
        electionInstance.candidates(i).then(function (candidate) {

          // Assigning each element to a variable for proper understanding.
          let id = candidate[0];
          let name = candidate[1];
          let voteCount = candidate[2];
          let image = candidateImages[id];

          // Render candidate Result
          let candidateTemplate = "<tr><th>" + id + "</th><td><img src='" + image + "' alt='" + "' style='max-height: 35px; max-width: 35px;vertical-align:middle'> " + name + "</td><td>" + voteCount + "</td></tr>"
          candidatesResults.append(candidateTemplate);

          // Here we store the 
          votesObj[name] = voteCount.c[0];

          votesTally = votesObj;

          // Render candidate ballot option
          let candidateOption = "<option value='" + id + "' >" + name + "</ option>"
          candidatesSelect.append(candidateOption);
        });
      }
      return electionInstance.voters(App.account);
    }).then(function (hasVoted) {
      // Do not allow a user to vote
      if (hasVoted) {

        // If user has voted hide the form and display the Get Results button
        $('form').hide();
        $("#declareresults").show();
      }
      
      // Displaying and hiding elements.
      $('#loader').hide();
      $('#maincontent').show();
      $("#registration").hide();
      $("#votingresults").hide();
    }).catch(function (error) {

      // Log any error.
      console.warn(error);
    });
  },

  getResults: function () {

    // Checking which candidate has the maximum votes from the votesTally object
    let maxVal = Math.max(...Object.values(votesTally));
    let maxKeys = Object.keys(votesTally).filter(key => votesTally[key] === maxVal);

    // Creating an empty string variable for message.
    let votingResultsMessage = null;

    $("#votingresults").show();

    // Check if there is no tie and assign the message variable function accordingly.
    if (maxKeys.length > 1) {
      votingResultsMessage = "It's a tie!";
    } else {
      votingResultsMessage = `The candidate with the highest vote count is ${maxKeys[0]} with a total votes of ${maxVal}.`
    }

    // Finally populate the fron-end with appropriate message.
    let votingresults = $("#votingresults");
    votingresults.empty();
    votingresults.append(votingResultsMessage);

    // Hide the Get Results button once results declared.
    $("#declareresults").hide();
  },

  recordVote: function () {
    
    // Fetching the selected candidateId
    var candidateId = $('#candidatesSelect').val();

    //  Deployment and instance generation.
    App.contracts.Election.deployed().then(function (instance) {
      return instance.recordVote(candidateId, { from: App.account });
    }).then(function (result) {
      // Wait for votes to update
      $("#maincontent").hide();
      $("#loader").show();
      $("#registration").hide();
    }).catch(function (err) {

      // Log any error.
      console.error(err);
    });
  },

  registerVoter: function () {

    $("#registration").show();
    $("#maincontent").hide()
    $("#loader").hide();

    // Fetching inputs
    var votername = $('#votername').val();
    var voteremail = $('#voteremail').val();
    var voterid = $('#voterid').val();

    // Deployment and instance generation.
    App.contracts.Election.deployed().then(function (instance) {
      return instance.registerVoter(votername, voteremail, parseInt(voterid), { from: App.account });
    }).then(function (result) {

      $("#registration").hide();

      // Load the contract.
      App.loadContract();
    }).catch(function (err) {

      // Log any error.
      console.error(err);
    });
  }
};

// Loading pages and connecting the smart contract.
$(function () {
  $(window).load(function () {
    App.init();
  });
});
