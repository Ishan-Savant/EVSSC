var Election = artifacts.require("./Election.sol");

// TODO write test cases.
